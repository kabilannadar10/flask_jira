AWS_REGION = "ap-south-1"  # Change this if needed
LOG_GROUP = "JiraLogs"
LOG_STREAM = "JiraStream"
